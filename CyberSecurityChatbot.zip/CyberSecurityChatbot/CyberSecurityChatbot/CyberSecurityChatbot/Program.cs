﻿using System;

class Program
{
    static void Main()
    {
        Console.Title = "Cybersecurity Awareness Bot";

        AudioPlayer.PlayGreeting();   // plays voice
        UIHelper.ShowLogo();          // shows ASCII

        Chatbot bot = new Chatbot();
        bot.Start();                  // starts chatbot
    }
}