﻿using System;
using System.Media;
using System.IO;

public class AudioPlayer
{
    public static void PlayGreeting()
    {
        try
        {
            if (OperatingSystem.IsWindows())
            {
                string path = Path.Combine("Assets", "greeting.wav");

                if (File.Exists(path))
                {
                    SoundPlayer player = new SoundPlayer(path);
                    player.PlaySync();
                }
                else
                {
                    Console.WriteLine("Audio file not found.");
                }
            }
        }
        catch
        {
            Console.WriteLine("Error playing audio.");
        }
    }
}