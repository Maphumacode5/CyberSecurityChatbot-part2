﻿using System;

public class UIHelper
{
    public static void ShowLogo()
    {
        Console.ForegroundColor = ConsoleColor.Cyan;

        Console.WriteLine(@"
  ██████╗ ██╗   ██╗██████╗ ███████╗██████╗ 
 ██╔════╝ ██║   ██║██╔══██╗██╔════╝██╔══██╗
 ██║      ██║   ██║██████╔╝█████╗  ██████╔╝
 ██║      ██║   ██║██╔══██╗██╔══╝  ██╔══██╗
 ╚██████╗ ╚██████╔╝██████╔╝███████╗██║  ██║
  ╚═════╝  ╚═════╝ ╚═════╝ ╚══════╝╚═╝  ╚═╝

        🔐 CYBERSECURITY BOT 🔐
        ");

        Console.ResetColor();
    }
}