﻿using System;
using System.Threading;

public class Chatbot
{
    private string userName;

    // Start chatbot
    public void Start()
    {
        Console.Write("\nEnter your name: ");
        userName = Console.ReadLine();

        if (string.IsNullOrWhiteSpace(userName))
            userName = "User";

        Console.WriteLine($"\nHello, {userName}! Ask me about cybersecurity.");

        RunChat();
    }

    // Main chat loop
    private void RunChat()
    {
        while (true)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write("\nYou: ");
            Console.ResetColor();

            string inputRaw = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(inputRaw))
            {
                Console.WriteLine("Bot: Please type something.");
                continue;
            }

            string input = inputRaw.ToLower();

            if (input == "exit")
            {
                Console.WriteLine("Bot: Goodbye!");
                break;
            }

            string response = ResponseHandler.GetResponse(input);

            Console.ForegroundColor = ConsoleColor.Yellow;
            TypeEffect("Bot: " + response);
            Console.ResetColor();
        }
    }

    // Cybersecurity responses (DETAILED)
    private string GetResponse(string input)
    {
        if (input.Contains("password"))
            return "A strong password should be at least 12 characters long and include uppercase letters, lowercase letters, numbers, and symbols. Avoid reusing passwords.";

        if (input.Contains("phishing"))
            return "Phishing is a scam where attackers trick you into giving personal information through fake emails or websites. Always verify links.";

        if (input.Contains("malware"))
            return "Malware is harmful software that damages systems or steals data. Use antivirus protection.";

        if (input.Contains("safe browsing"))
            return "Only visit secure websites (https) and avoid clicking unknown links.";

        return "I didn't understand. Try asking about passwords, phishing, or malware.";
    }

    // Typing animation
    private void TypeEffect(string message)
    {
        foreach (char c in message)
        {
            Console.Write(c);
            Thread.Sleep(20);
        }
        Console.WriteLine();
    }
}