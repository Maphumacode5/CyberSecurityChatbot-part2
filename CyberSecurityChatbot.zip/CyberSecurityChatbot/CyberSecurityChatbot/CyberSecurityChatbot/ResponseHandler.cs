﻿using System;

// Handles all chatbot responses with detailed explanations and options
public class ResponseHandler
{
    // Stores last topic for follow-up options
    public static string lastTopic = "";

    public static string GetResponse(string input)
    {
        input = input.ToLower();

        // ================= PASSWORD =================
        if (input.Contains("password"))
        {
            lastTopic = "password";

            return "Passwords protect your accounts from unauthorized access.\n\n" +
                   "Example:\nWeak: 123456\nStrong: T@k3MyS3cur3P@ss!\n\n" +
                   "Choose an option:\n" +
                   "1. How to create strong passwords\n" +
                   "2. Common password mistakes\n" +
                   "3. What is a password manager?\n" +
                   "4. Go back";
        }

        // ================= PHISHING =================
        if (input.Contains("phishing"))
        {
            lastTopic = "phishing";

            return "Phishing is when attackers trick you into giving personal information.\n\n" +
                   "Example: Fake email saying 'Your bank account is locked'.\n\n" +
                   "Choose an option:\n" +
                   "1. How to identify phishing\n" +
                   "2. Real-life examples\n" +
                   "3. What to do if attacked\n" +
                   "4. Go back";
        }

        // ================= MALWARE =================
        if (input.Contains("malware") || input.Contains("virus"))
        {
            lastTopic = "malware";

            return "Malware is harmful software that damages or steals data.\n\n" +
                   "Example: Ransomware locks your files and asks for money.\n\n" +
                   "Choose an option:\n" +
                   "1. Types of malware\n" +
                   "2. How malware spreads\n" +
                   "3. How to protect yourself\n" +
                   "4. Go back";
        }

        // ================= VPN =================
        if (input.Contains("vpn"))
        {
            lastTopic = "vpn";

            return "A VPN protects your internet connection.\n\n" +
                   "Example: Using public Wi-Fi safely.\n\n" +
                   "Choose an option:\n" +
                   "1. How VPN works\n" +
                   "2. Benefits of VPN\n" +
                   "3. When to use VPN\n" +
                   "4. Go back";
        }

        // ================= 2FA =================
        if (input.Contains("2fa") || input.Contains("two factor"))
        {
            lastTopic = "2fa";

            return "2FA adds extra security to your accounts.\n\n" +
                   "Example: Password + SMS code.\n\n" +
                   "Choose an option:\n" +
                   "1. Why 2FA is important\n" +
                   "2. Types of 2FA\n" +
                   "3. How to enable 2FA\n" +
                   "4. Go back";
        }

        // ================= PRIVACY =================
        if (input.Contains("privacy"))
        {
            lastTopic = "privacy";

            return "Online privacy protects your personal data.\n\n" +
                   "Example: Avoid sharing personal info on social media.\n\n" +
                   "Choose an option:\n" +
                   "1. Risks of poor privacy\n" +
                   "2. How to stay private\n" +
                   "3. Social media safety\n" +
                   "4. Go back";
        }

        // ================= FOLLOW-UPS =================

        // PASSWORD OPTIONS
        if (lastTopic == "password")
        {
            if (input == "1")
                return "Use long phrases like 'MyDogLoves2Run!' with symbols and numbers.";
            if (input == "2")
                return "Avoid names, birthdays, or simple passwords like '123456'.";
            if (input == "3")
                return "A password manager securely stores and generates strong passwords.";
            if (input == "4")
            {
                lastTopic = "";
                return "Returning to main topics.";
            }
        }

        // PHISHING OPTIONS
        if (lastTopic == "phishing")
        {
            if (input == "1")
                return "Look for spelling errors, urgent messages, and strange email addresses.";
            if (input == "2")
                return "Example: Fake PayPal email asking you to log in.";
            if (input == "3")
                return "Change your password immediately and report the attack.";
            if (input == "4")
            {
                lastTopic = "";
                return "Returning to main topics.";
            }
        }

        // MALWARE OPTIONS
        if (lastTopic == "malware")
        {
            if (input == "1")
                return "Types include viruses, worms, ransomware, and spyware.";
            if (input == "2")
                return "Malware spreads through downloads, emails, and unsafe websites.";
            if (input == "3")
                return "Use antivirus software and avoid suspicious files.";
            if (input == "4")
            {
                lastTopic = "";
                return "Returning to main topics.";
            }
        }

        // VPN OPTIONS
        if (lastTopic == "vpn")
        {
            if (input == "1")
                return "VPN encrypts your internet traffic.";
            if (input == "2")
                return "It protects privacy and hides your IP address.";
            if (input == "3")
                return "Use VPN on public Wi-Fi.";
            if (input == "4")
            {
                lastTopic = "";
                return "Returning to main topics.";
            }
        }

        // 2FA OPTIONS
        if (lastTopic == "2fa")
        {
            if (input == "1")
                return "2FA prevents hackers from accessing your account even if they know your password.";
            if (input == "2")
                return "Types include SMS codes, apps, and biometrics.";
            if (input == "3")
                return "Enable 2FA in your account settings.";
            if (input == "4")
            {
                lastTopic = "";
                return "Returning to main topics.";
            }
        }

        // PRIVACY OPTIONS
        if (lastTopic == "privacy")
        {
            if (input == "1")
                return "Poor privacy can lead to identity theft.";
            if (input == "2")
                return "Use strong passwords and limit data sharing.";
            if (input == "3")
                return "Avoid posting personal details publicly.";
            if (input == "4")
            {
                lastTopic = "";
                return "Returning to main topics.";
            }
        }

        // DEFAULT
        return "Ask about cybersecurity topics like passwords, phishing, malware, VPN, 2FA, or privacy.";
    }
}